<template>
  <div id="home">
    <MessageBoard/>
  </div>
</template>

<script>
  import MessageBoard from "@/components/MessageBoard";
  export default {
    name: 'Home',
    components: {
      MessageBoard
    }
  }
</script>
