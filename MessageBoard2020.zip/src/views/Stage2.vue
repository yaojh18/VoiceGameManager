
<template>
  <div id="stage2">
    <MessageList/>
  </div>
</template>

<script>
  import MessageList from "@/components/MessageList.vue";
  export default {
    name: 'Stage2',
    components: {
      MessageList
    }
  }
</script>
