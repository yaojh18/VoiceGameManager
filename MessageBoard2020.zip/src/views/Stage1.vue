
<template>
    <div id="stage1">
        <MessageBlock/>
    </div>
</template>

<script>
    import MessageBlock from "@/components/MessageBlock.vue";
    export default {
        name: 'Stage1',
        components: {
        MessageBlock
        }
    }
</script>
