<template>
  <div id="add">
    <Add/>
  </div>
</template>

<script>
import Add from "@/components/Add.vue"

export default {
  name: 'Add',
  components: {
    Add,
  },
  methods: {
  }
}
</script>