<template>
  <div id="data">
    <Data/>
  </div>
</template>

<script>
  import Data from "@/components/Data";
  export default {
    name: 'DataView',
    components: {
        Data
    }
  }
</script>
