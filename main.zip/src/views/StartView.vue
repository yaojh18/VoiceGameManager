<template>
  <div id="person">
    <Start/>
  </div>
</template>

<script>
import Start from "@/components/Start.vue";
export default {
  name: 'StartView',
  components: {
    Start,
  }
}
</script>